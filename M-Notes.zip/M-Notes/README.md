# M Notes

تطبيق ويب (PWA) لإدارة المهام والطلبات الذكية — by **MOAMEN MEKKI**.

Smart Tasks & Requests PWA (Arabic / English, RTL support).

## Features
- Tasks & requests management
- Themes, fonts and custom banner
- Installable PWA (works offline)
- Local backup + optional Firebase cloud backup (Gmail / Phone login)
- Export / Import backup as JSON

## Project structure
```
index.html        # main app
manifest.json     # PWA manifest
sw.js             # service worker (offline cache)
backup-cloud.js   # backup logic + Firebase
LICENSE
```

## Run locally
Service workers need http(s), so don't open the file directly. Use a local server:
```bash
python3 -m http.server 8000
# then open http://localhost:8000
```

## Deploy on GitHub Pages
1. Push the files to a repo.
2. Settings → Pages → Branch: `main` / root → Save.
3. Open `https://<username>.github.io/<repo>/`

## Enable cloud backup (optional)
1. Create a Firebase project and enable Authentication (Google / Phone) and Firestore.
2. Put your web config values in `backup-cloud.js` (`firebaseConfig`).
3. Firestore rules:
```
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /mnotes_backups/{uid} {
      allow read, write: if request.auth != null && request.auth.uid == uid;
    }
  }
}
```
4. Add your GitHub Pages domain in Firebase → Authentication → Authorized domains.

> After editing any file, bump `CACHE_NAME` in `sw.js` (e.g. `m-notes-v2`) so users get the update.

## License
All Rights Reserved © 2026 MOAMEN MEKKI. See [LICENSE](LICENSE).
